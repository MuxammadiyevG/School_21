#include "s21_string.h"

#include <stdio.h>

void s21_strlen_test();
void s21_strcmp_test();
void s21_strcpy_test();
void s21_strcat_test();
void s21_strchr_test();
void s21_strstr_test();
void s21_strtok_test();

int main() {
#ifdef Quest_1
    s21_strlen_test();
#endif
#ifdef Quest_2
    s21_strcmp_test();
#endif
#ifdef Quest_3
    s21_strcpy_test();
#endif
#ifdef Quest_4
    s21_strcat_test();
#endif
#ifdef Quest_5
    s21_strchr_test();
#endif
#ifdef Quest_6
    s21_strstr_test();
#endif
#ifdef Quest_7
    s21_strtok_test();
#endif
}

void s21_strlen_test() {
    char str1[30] = "Assalomu alaykum";
    char str2[30] = "bu mening []_ 10-loyiham;'";
    char str3[30] = "";
    char str4[50] = "bu loyiha juda qiyin bo'ldi ammo uddaladim";
    char* arr[4] = {str1, str2, str3, str4};
    int sizes[4] = {16, 26, 0, 42};

    for (int i = 0; i < 4; i++) {
        printf("INPUT: %s OUTPUT: %d RESULT: ", arr[i], s21_strlen(arr[i]));
        if (s21_strlen(arr[i]) == sizes[i])
            printf("SUCCESS\n");
        else
            printf("FAIL\n");
    }
}

void s21_strcmp_test() {
    char str1[30] = "salom";
    char str2[30] = "salom";
    char str3[30] = "va alaykum assalom";
    char str4[30] = "Va alaykum assalom'";
    printf("INPUT: %s %s OUTPUT: %d RESULT: %s\n", str1, str2, s21_strcmp(str1, str2),
           (s21_strcmp(str1, str2) == 0) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %s OUTPUT: %d RESULT: %s\n", str1, str3, s21_strcmp(str1, str3),
           (s21_strcmp(str1, str3) < 0) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %s OUTPUT: %d RESULT: %s\n", str3, str4, s21_strcmp(str3, str4),
           (s21_strcmp(str3, str4) > 0) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %s OUTPUT: %d RESULT: %s\n", str1, str4, s21_strcmp(str1, str4),
           (s21_strcmp(str1, str4) > 0) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %s OUTPUT: %d RESULT: %s\n", str3, str2, s21_strcmp(str3, str2),
           (s21_strcmp(str3, str2) > 0) ? "SUCCESS" : "FAIL");
}

void s21_strcpy_test() {
    char str1[30] = "";
    char str2[30] = "hello";
    char str3[30] = "How are you";
    char str4[30] = "I am fine";
    char str5[30] = "english";
    s21_strcpy(str1, str2);
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str1, str2, str1,
           (s21_strcmp(str1, str2) == 0) ? "SUCCESS" : "FAIL");
    s21_strcpy(str3, str1);
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str3, str1, str3,
           (s21_strcmp(str3, str1) == 0) ? "SUCCESS" : "FAIL");
    s21_strcpy(str4, str5);
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str4, str5, str4,
           (s21_strcmp(str4, str5) == 0) ? "SUCCESS" : "FAIL");
    s21_strcpy(str1, str5);
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str1, str5, str1,
           (s21_strcmp(str1, str5) == 0) ? "SUCCESS" : "FAIL");
}

void s21_strcat_test() {
    char str1[30] = "";
    char str2[30] = "bir";
    char str3[30] = "ikki";
    char str4[30] = "uch";
    char str5[30] = "besh";
    char str6[30] = "besh";
    s21_strcat(str1, str2);
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str1, str2, str1,
           (s21_strcmp(str1, str2) == 0) ? "SUCCESS" : "FAIL");
    s21_strcat(str3, str1);
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str3, str1, str3,
           (s21_strcmp(str3, str1) == 0) ? "SUCCESS" : "FAIL");
    s21_strcat(str4, str1);
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str4, str1, str4,
           (s21_strcmp(str4, str1) == 0) ? "SUCCESS" : "FAIL");
    s21_strcat(str5, "");
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str5, "", str5,
           (s21_strcmp(str5, str6) == 0) ? "SUCCESS" : "FAIL");
}

void s21_strchr_test() {
    char str1[30] = "1234567890";
    char str2[30] = "Hello, World!";
    char str3[30] = "Aboba";
    char str4[30] = "";
    printf("INPUT: %s %c OUTPUT: %s RESULT: %s\n", str1, '9', s21_strchr(str1, '9'),
           (s21_strchr(str1, '9') != NULL) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %c OUTPUT: %s RESULT: %s\n", str2, 'W', s21_strchr(str2, 'W'),
           (s21_strchr(str2, 'W') != NULL) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %c OUTPUT: %s RESULT: %s\n", str3, 'c', s21_strchr(str3, 'c'),
           (s21_strchr(str3, 'c') == NULL) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %c OUTPUT: %s RESULT: %s\n", str4, 'c', s21_strchr(str4, 'c'),
           (s21_strchr(str4, 'c') == NULL) ? "SUCCESS" : "FAIL");
}

void s21_strstr_test() {
    char str1[30] = "1234567890";
    char str2[30] = "Hello, World!";
    char str3[30] = "Aboba";
    char str4[30] = "";
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str1, "234", s21_strstr(str1, "234"),
           (s21_strstr(str1, "234") != NULL) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str2, "World", s21_strstr(str2, "World"),
           (s21_strstr(str2, "World") != NULL) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str3, "biba", s21_strstr(str3, "biba"),
           (s21_strstr(str3, "biba") == NULL) ? "SUCCESS" : "FAIL");
    printf("INPUT: %s %s OUTPUT: %s RESULT: %s\n", str4, "biba", s21_strstr(str4, "biba"),
           (s21_strstr(str4, "biba") == NULL) ? "SUCCESS" : "FAIL");
}

void s21_strtok_test() {
    char str1[50] = "Eng qiyin tasklardan biri";
    char* res;
    res = s21_strtok(str1, " ");
    printf("INPUT: %s OUTPUT: %s RESULT: %s\n", str1, res,
           (s21_strcmp(res, "Eng") == 0) ? "SUCCESS" : "FAIL");
    res = s21_strtok(NULL, " ");
    printf("INPUT: %s OUTPUT: %s RESULT: %s\n", str1, res,
           (s21_strcmp(res, "qiyin") == 0) ? "SUCCESS" : "FAIL");
    res = s21_strtok(NULL, " ");
    printf("INPUT: %s OUTPUT: %s RESULT: %s\n", str1, res,
           (s21_strcmp(res, "tasklardan") == 0) ? "SUCCESS" : "FAIL");
    res = s21_strtok(NULL, " ");
    printf("INPUT: %s OUTPUT: %s RESULT: %s\n", str1, res,
           (s21_strcmp(res, "biri") == 0) ? "SUCCESS" : "FAIL");
    res = s21_strtok(NULL, " ");
    printf("INPUT: %s OUTPUT: %s RESULT: %s\n", str1, res, (res == NULL) ? "SUCCESS" : "FAIL");
}
