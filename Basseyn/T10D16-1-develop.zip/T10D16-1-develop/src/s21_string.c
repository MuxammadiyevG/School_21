#include "s21_string.h"
static char* old;
int s21_strlen(char* text) {
    int length = 0;
    while (text[length] != '\0') {
        length++;
    }
    return length;
}
int s21_strcmp(char* text, char* text1) {
    while (*text == *text1++)
        if (*text++ == '\0') return 0;
    return (*(const unsigned char*)text - *(const unsigned char*)(text1 - 1));
}
char* s21_strcpy(char* text, char* text1) {
    while (*text1 != '\0') {
        *text = *text1;
        text++;
        text1++;
    }
    *text = '\0';
    return text;
}

char* s21_strcat(char* text, char* text1) {
    while (*text != '\0') text++;
    while (*text1 != '\0') {
        *text = *text1;
        text++;
        text1++;
    }
    *text = '\0';
    return text;
}

char* s21_strchr(char* str, char sym) {
    char* ptr = 0;
    while (*str != '\0') {
        if (*str == sym) ptr = str;
        str++;
    }
    return ptr;
}

char* s21_strstr(char* text, char* text1) {
    char* ptr = 0;
    while (*text != '\0') {
        char* tmp = text;
        char* tmp2 = text1;
        while (*tmp == *tmp2) {
            tmp++;
            tmp2++;
            if (*tmp2 == '\0') ptr = text;
        }
        text++;
    }
    return ptr;
}

char* s21_strtok(char* str, char* delim) {
    char* token;
    if (str == 0) {
        str = old;
    }
    if (str == 0) return 0;
    token = str;
    int flag = 1;
    while ((*str != '\0') && (flag)) {
        char* tmp = delim;
        while (*tmp != '\0') {
            if (*str == *tmp) {
                *str = '\0';
                flag = 0;
                break;
            }
            tmp++;
        }
        str++;
    }
    if (flag == 0)
        old = str;
    else
        old = 0;
    return token;
}