#include "list.h"

#include <stdio.h>

#define SUCCESS 0
#define FAIL 1

int test_add_door() {
    struct door door1 = {1};
    struct door door2 = {2};
    struct door door3 = {3};

    struct node *root = init(&door1);
    if (root == NULL || root->door->id != 1) {
        return FAIL;
    }

    struct node *second = add_door(root, &door2);
    if (second == NULL || second->door->id != 2 || root->next != second) {
        return FAIL;
    }

    struct node *third = add_door(second, &door3);
    if (third == NULL || third->door->id != 3 || second->next != third) {
        return FAIL;
    }

    destroy(root);
    return SUCCESS;
}

int test_remove_door() {
    struct door door1 = {1};
    struct door door2 = {2};
    struct door door3 = {3};

    struct node *root = init(&door1);
    struct node *second = add_door(root, &door2);
    struct node *third = add_door(second, &door3);

    root = remove_door(second, root);
    if (find_door(2, root) != NULL || root->next != third) {
        destroy(root);
        return FAIL;
    }

    root = remove_door(root, root);
    if (find_door(1, root) != NULL || root != third) {
        destroy(root);
        return FAIL;
    }

    destroy(root);
    return SUCCESS;
}

int main() {
    if (test_add_door() == SUCCESS) {
        printf("test_add_door: SUCCESS\n");
    } else {
        printf("test_add_door: FAIL\n");
    }

    if (test_remove_door() == SUCCESS) {
        printf("test_remove_door: SUCCESS\n");
    } else {
        printf("test_remove_door: FAIL\n");
    }

    return 0;
}
