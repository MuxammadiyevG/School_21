#ifndef DOOR_F
#define DOOR_F

struct door {
    int id;
    int status;
};

void initialize_doors(struct door* doors);
void sort_doors(struct door* doors);
void print_doors(struct door* doors);

#endif  // DOOR_F
