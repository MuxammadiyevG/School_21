#ifndef STACK_H
#define STACK_H

struct elem {
    int val;
    struct elem* next;
};

struct elem* init(int val);
void push(struct elem** head, int val);
int pop(struct elem** head);
void destroy(struct elem** head);

#endif  // STACK_H
