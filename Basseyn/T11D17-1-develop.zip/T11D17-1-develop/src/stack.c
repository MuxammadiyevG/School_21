#include "stack.h"

#include <stdlib.h>

struct elem* init(int val) {
    struct elem* head = (struct elem*)malloc(sizeof(struct elem));
    if (head == NULL) {
        return NULL;  // handle allocation failure
    }
    head->val = val;
    head->next = NULL;
    return head;
}

void push(struct elem** head, int val) {
    struct elem* tmp = (struct elem*)malloc(sizeof(struct elem));
    if (tmp == NULL) {
        return;  // handle allocation failure
    }
    tmp->val = val;
    tmp->next = *head;
    *head = tmp;
}

int pop(struct elem** head) {
    if (*head == NULL) {
        return -1;  // or handle the empty stack case appropriately
    }
    struct elem* tmp = *head;
    int value = tmp->val;
    *head = (*head)->next;
    free(tmp);
    return value;
}

void destroy(struct elem** head) {
    struct elem* current = *head;
    struct elem* next = NULL;

    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }

    *head = NULL;
}
