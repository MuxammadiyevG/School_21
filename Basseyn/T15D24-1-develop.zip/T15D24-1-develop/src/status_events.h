#ifndef SRC_STATUS_EVENTS_H
#define SRC_STATUS_EVENTS_H

#include "libs.h"

int print_events(FILE* ptr);

#endif  // SRC_STATUS_EVENTS_H
