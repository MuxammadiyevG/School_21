#include "levels.h"
#include "libs.h"
#include "modules.h"

void modules_operations(FILE* f);
void levels_operations(FILE* f);

int main() {
    FILE* modules_file = fopen(modules_fpath, "r+b");
    FILE* levels_file = fopen(levels_fpath, "r+b");

    if (modules_file == NULL || levels_file == NULL) {
        printf("Error opening file\n");
        return 1;
    }

    int choice;

    do {
        printf("Choose an operation:\n");
        printf("1. Modules operations\n");
        printf("2. Levels operations\n");
        printf("0. Exit\n");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                modules_operations(modules_file);
                break;
            case 2:
                levels_operations(levels_file);
                break;
            case 0:
                break;
            default:
                printf("Invalid choice\n");
        }
    } while (choice != 0);

    fclose(modules_file);
    fclose(levels_file);

    return 0;
}

void modules_operations(FILE* f) {
    int choice;
    do {
        printf("Modules operations:\n");
        printf("1. Print all modules\n");
        printf("2. Add a module\n");
        printf("3. Delete a module\n");
        printf("4. Change a module\n");
        printf("5. Insert a module\n");
        printf("0. Back\n");
        scanf("%d", &choice);

        int id;
        modules rec;

        switch (choice) {
            case 1:
                print_modules(f);
                break;
            case 2:
                rec = getModulesRecord(getLastId(f) + 1);
                addModulesRecord(f, rec);
                break;
            case 3:
                printf("Enter module ID to delete:\n");
                scanf("%d", &id);
                deleteModulesRecord(f, id);
                break;
            case 4:
                printf("Enter module ID to change:\n");
                scanf("%d", &id);
                rec = getModulesRecord(id);
                changeModulesRecord(f, id, rec);
                break;
            case 5:
                printf("Enter module ID to insert at:\n");
                scanf("%d", &id);
                rec = getModulesRecord(id);
                insertModulesRecord(f, id, rec);
                break;
            case 0:
                break;
            default:
                printf("Invalid choice\n");
        }
    } while (choice != 0);
}

void levels_operations(FILE* f) {
    int choice;
    do {
        printf("Levels operations:\n");
        printf("1. Print all levels\n");
        printf("2. Add a level\n");
        printf("3. Delete a level\n");
        printf("4. Change a level\n");
        printf("5. Insert a level\n");
        printf("0. Back\n");
        scanf("%d", &choice);

        int id;
        levels rec;

        switch (choice) {
            case 1:
                print_levels(f);
                break;
            case 2:
                rec = getLevelsRecord();
                addLevelsRecord(f, rec);
                break;
            case 3:
                printf("Enter level ID to delete:\n");
                scanf("%d", &id);
                deleteLevelsRecord(f, id);
                break;
            case 4:
                printf("Enter level ID to change:\n");
                scanf("%d", &id);
                rec = getLevelsRecord();
                changeLevelsRecord(f, id, rec);
                break;
            case 5:
                printf("Enter level ID to insert at:\n");
                scanf("%d", &id);
                rec = getLevelsRecord();
                insertLevelsRecord(f, id, rec);
                break;
            case 0:
                break;
            default:
                printf("Invalid choice\n");
        }
    } while (choice != 0);
}
