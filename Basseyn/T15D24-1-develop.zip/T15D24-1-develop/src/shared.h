#ifndef SRC_SHARED_H_
#define SRC_SHARED_H_

int modulesControll();
int showTables();
int getChoice(int gap1, int gap2);
int levelsControll();

#endif  // SRC_SHARED_H_
