/*void invert(double **matrix, int n, int m);
void input(double **matrix, int *n, int *m);
void output(double **matrix, int n, int m);


void main()
{

}
*/
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

void input(double ***matrix, int *n, int *m);
void output(double **matrix, int n);
void free_matrix(double **matrix, int n);
double **inverse(double **matrix, int n);

int main() {
    double **matrix = NULL;
    int n, m;

    input(&matrix, &n, &m);

    if (matrix == NULL || n != m) {
        printf("n/a");
        return 0;
    }

    double **inv_matrix = inverse(matrix, n);

    if (inv_matrix == NULL) {
        printf("n/a");
    } else {
        output(inv_matrix, n);
        free_matrix(inv_matrix, n);
    }

    free_matrix(matrix, n);

    return 0;
}

void input(double ***matrix, int *n, int *m) {
    if (scanf("%d %d", n, m) != 2 || *n <= 0 || *m <= 0) {
        *matrix = NULL;
        return;
    }

    *matrix = (double **)malloc(*n * sizeof(double *));
    for (int i = 0; i < *n; ++i) {
        (*matrix)[i] = (double *)malloc(*m * sizeof(double));
        for (int j = 0; j < *m; ++j) {
            if (scanf("%lf", &((*matrix)[i][j])) != 1) {
                *matrix = NULL;
                return;
            }
        }
    }
}

void output(double **matrix, int n) {
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            printf("%.6lf", matrix[i][j]);
            if (j < n - 1) {
                printf(" ");
            }
        }
        if (i < n - 1) {
            printf("\n");
        }
    }
}

void free_matrix(double **matrix, int n) {
    for (int i = 0; i < n; ++i) {
        free(matrix[i]);
    }
    free(matrix);
}

double **inverse(double **matrix, int n) {
    double **inv_matrix = (double **)malloc(n * sizeof(double *));
    for (int i = 0; i < n; ++i) {
        inv_matrix[i] = (double *)malloc(n * sizeof(double));
    }

    double **augmented_matrix = (double **)malloc(n * sizeof(double *));
    for (int i = 0; i < n; ++i) {
        augmented_matrix[i] = (double *)malloc(2 * n * sizeof(double));
        for (int j = 0; j < n; ++j) {
            augmented_matrix[i][j] = matrix[i][j];
        }
        for (int j = n; j < 2 * n; ++j) {
            augmented_matrix[i][j] = (i == j - n) ? 1.0 : 0.0;
        }
    }

    for (int i = 0; i < n; ++i) {
        if (fabs(augmented_matrix[i][i]) < 1e-9) {
            free_matrix(augmented_matrix, n);
            free_matrix(inv_matrix, n);
            return NULL;
        }

        double diag_element = augmented_matrix[i][i];
        for (int j = 0; j < 2 * n; ++j) {
            augmented_matrix[i][j] /= diag_element;
        }

        for (int k = 0; k < n; ++k) {
            if (k != i) {
                double factor = augmented_matrix[k][i];
                for (int j = 0; j < 2 * n; ++j) {
                    augmented_matrix[k][j] -= factor * augmented_matrix[i][j];
                }
            }
        }
    }

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            inv_matrix[i][j] = augmented_matrix[i][j + n];
        }
    }

    free_matrix(augmented_matrix, n);

    return inv_matrix;
}
