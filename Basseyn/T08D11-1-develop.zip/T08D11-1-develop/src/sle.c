#include <math.h>
#include <stdio.h>
#include <stdlib.h>

void input(double ***matrix, double **constants, int *n);
void output(double *solutions, int n, int status);
void free_matrix(double **matrix, int n);
void free_vector(double *vector);
double determinant(double **matrix, int n);
double **create_submatrix(double **matrix, double *constants, int n, int col);
double *cramers_rule(double **matrix, double *constants, int n);

int main() {
    double **matrix = NULL;
    double *constants = NULL;
    int n;

    input(&matrix, &constants, &n);

    if (matrix == NULL || constants == NULL) {
        printf("n/a");
        return 0;
    }

    double *solutions = cramers_rule(matrix, constants, n);

    if (solutions == NULL) {
        printf("n/a");
    } else {
        output(solutions, n, 1);
        free_vector(solutions);
    }

    free_matrix(matrix, n);
    free_vector(constants);

    return 0;
}

void input(double ***matrix, double **constants, int *n) {
    int m;
    if (scanf("%d %d", n, &m) != 2 || *n <= 0 || m != *n + 1) {
        *matrix = NULL;
        *constants = NULL;
        return;
    }

    *matrix = (double **)malloc(*n * sizeof(double *));
    *constants = (double *)malloc(*n * sizeof(double));

    for (int i = 0; i < *n; ++i) {
        (*matrix)[i] = (double *)malloc(*n * sizeof(double));
        for (int j = 0; j < *n; ++j) {
            if (scanf("%lf", &((*matrix)[i][j])) != 1) {
                *matrix = NULL;
                *constants = NULL;
                return;
            }
        }
        if (scanf("%lf", &((*constants)[i])) != 1) {
            *matrix = NULL;
            *constants = NULL;
            return;
        }
    }
}

void output(double *solutions, int n, int status) {
    if (status) {
        for (int i = 0; i < n; ++i) {
            printf("%.6lf", solutions[i]);
            if (i < n - 1) {
                printf(" ");
            }
        }
    } else {
        printf("n/a");
    }
}

void free_matrix(double **matrix, int n) {
    for (int i = 0; i < n; ++i) {
        free(matrix[i]);
    }
    free(matrix);
}

void free_vector(double *vector) { free(vector); }

double determinant(double **matrix, int n) {
    if (n == 1) {
        return matrix[0][0];
    }
    if (n == 2) {
        return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
    }

    double det = 0.0;
    double **submatrix = (double **)malloc((n - 1) * sizeof(double *));
    for (int i = 0; i < n - 1; ++i) {
        submatrix[i] = (double *)malloc((n - 1) * sizeof(double));
    }

    for (int x = 0; x < n; ++x) {
        int subi = 0;
        for (int i = 1; i < n; ++i) {
            int subj = 0;
            for (int j = 0; j < n; ++j) {
                if (j == x) continue;
                submatrix[subi][subj] = matrix[i][j];
                subj++;
            }
            subi++;
        }
        det += pow(-1, x) * matrix[0][x] * determinant(submatrix, n - 1);
    }

    for (int i = 0; i < n - 1; ++i) {
        free(submatrix[i]);
    }
    free(submatrix);

    return det;
}

double **create_submatrix(double **matrix, double *constants, int n, int col) {
    double **submatrix = (double **)malloc(n * sizeof(double *));
    for (int i = 0; i < n; ++i) {
        submatrix[i] = (double *)malloc(n * sizeof(double));
        for (int j = 0; j < n; ++j) {
            submatrix[i][j] = (j == col) ? constants[i] : matrix[i][j];
        }
    }
    return submatrix;
}

double *cramers_rule(double **matrix, double *constants, int n) {
    double det = determinant(matrix, n);
    if (fabs(det) < 1e-9) {
        return NULL;
    }

    double *solutions = (double *)malloc(n * sizeof(double));
    for (int i = 0; i < n; ++i) {
        double **submatrix = create_submatrix(matrix, constants, n, i);
        solutions[i] = determinant(submatrix, n) / det;
        free_matrix(submatrix, n);
    }

    return solutions;
}
