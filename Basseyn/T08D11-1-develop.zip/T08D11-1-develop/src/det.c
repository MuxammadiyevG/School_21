#include <math.h>
#include <stdio.h>
#include <stdlib.h>
double det(double **matrix, int n);
void input(double ***matrix, int *n, int *m);
void output(double det, int status);
void free_matrix(double **matrix, int n);
int scanf_n(int *n);

int main() {
    double **matrix = NULL;
    int n, m;

    input(&matrix, &n, &m);

    if (matrix == NULL) {
        printf("n/a");
        return 0;
    }

    if (n != m) {
        printf("n/a");
        free_matrix(matrix, n);
        return 0;
    }

    double determinant = det(matrix, n);
    output(determinant, determinant != -1.0);

    free_matrix(matrix, n);

    return 0;
}

void input(double ***matrix, int *n, int *m) {
    if (scanf("%d %d", n, m) != 2 || *n <= 0 || *m <= 0) {
        *matrix = NULL;
        return;
    }

    *matrix = (double **)malloc(*n * sizeof(double *));
    for (int i = 0; i < *n; ++i) {
        (*matrix)[i] = (double *)malloc(*m * sizeof(double));
        for (int j = 0; j < *m; ++j) {
            if (scanf("%lf", &((*matrix)[i][j])) != 1) {
                *matrix = NULL;
                return;
            }
        }
    }
}

void output(double det, int status) {
    if (status) {
        printf("%.6lf", det);
    } else {
        printf("n/a");
    }
}

double det(double **matrix, int n) {
    if (n == 1) {
        return matrix[0][0];
    }

    double determinant = 0.0;
    double **submatrix = (double **)malloc((n - 1) * sizeof(double *));
    for (int i = 0; i < n - 1; ++i) {
        submatrix[i] = (double *)malloc((n - 1) * sizeof(double));
    }

    for (int x = 0; x < n; x++) {
        int subi = 0;
        for (int i = 1; i < n; i++) {
            int subj = 0;
            for (int j = 0; j < n; j++) {
                if (j == x) continue;
                submatrix[subi][subj] = matrix[i][j];
                subj++;
            }
            subi++;
        }
        double subdet = det(submatrix, n - 1);
        if (subdet == -1.0) return -1.0;
        determinant = determinant + (pow(-1, x) * matrix[0][x] * subdet);
    }

    for (int i = 0; i < n - 1; ++i) {
        free(submatrix[i]);
    }
    free(submatrix);

    return determinant;
}

void free_matrix(double **matrix, int n) {
    for (int i = 0; i < n; ++i) {
        free(matrix[i]);
    }
    free(matrix);
}
