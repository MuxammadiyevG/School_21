#include <stdio.h>
#define NMAX 10
void sort(int *a, int n);
int input(int *a, int n);
void output(int *a, int n);
int main() {
    int arr[NMAX];
    int *ptr;
    ptr = arr;
    if (input(ptr, NMAX) != -1) {
        sort(ptr, NMAX);
        output(ptr, NMAX);
    } else {
        printf("n/a");
    }
    return 0;
}
int input(int *a, int n) {
    int count = 0;
    while (count < n) {
        if (scanf("%d", count + a) != 1) {
            return -1;
        }
        count++;
    }
    return 0;
}
void output(int *a, int n) {
    int count = 0;
    while (count < n) {
        printf("%d ", *(a + count));
        count++;
    }
}
void sort(int *a, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (*(a + i) > *(a + j)) {
                int ptr = *(a + i);
                *(a + i) = *(a + j);
                *(a + j) = ptr;
            }
        }
    }
}