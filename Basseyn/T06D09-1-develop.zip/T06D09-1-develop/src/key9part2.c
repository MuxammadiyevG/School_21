#include <stdio.h>
#define LEN 100

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length);
void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length);
int input(int *buff);

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length) {
    int carry = 0;
    int max_len = len1 > len2 ? len1 : len2;
    *result_length = max_len;

    for (int i = 0; i < max_len; i++) {
        int num1 = (i < len1) ? buff1[len1 - 1 - i] : 0;
        int num2 = (i < len2) ? buff2[len2 - 1 - i] : 0;
        int sum = num1 + num2 + carry;
        result[max_len - 1 - i] = sum % 10;
        carry = sum / 10;
    }

    if (carry > 0) {
        for (int i = *result_length; i > 0; i--) {
            result[i] = result[i - 1];
        }
        result[0] = carry;
        (*result_length)++;
    }

    while (*result_length > 1 && result[0] == 0) {
        for (int i = 0; i < *result_length - 1; i++) {
            result[i] = result[i + 1];
        }
        (*result_length)--;
    }
}

void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length) {
    int borrow = 0;
    int max_len = len1 > len2 ? len1 : len2;
    *result_length = max_len;

    for (int i = 0; i < max_len; i++) {
        int num1 = (i < len1) ? buff1[len1 - 1 - i] : 0;
        int num2 = (i < len2) ? buff2[len2 - 1 - i] : 0;

        if (num1 < num2 + borrow) {
            result[max_len - 1 - i] = (10 + num1 - num2 - borrow);
            borrow = 1;
        } else {
            result[max_len - 1 - i] = num1 - num2 - borrow;
            borrow = 0;
        }
    }

    if (borrow > 0) {
        *result_length = 0;
    }

    while (*result_length > 1 && result[0] == 0) {
        for (int i = 0; i < *result_length - 1; i++) {
            result[i] = result[i + 1];
        }
        (*result_length)--;
    }
}

int input(int *buff) {
    int length = 0;
    for (int i = 0; i < LEN; i++) {
        char t;
        if (scanf("%d%c", &buff[i], &t) == 2 && t != '\n') {
            length++;
        } else if (t == '\n') {
            length++;
            break;
        } else {
            break;
        }
    }
    return length;
}

int main() {
    int buff1[LEN], buff2[LEN], result[LEN + 1], result_length = 0;

    int len1 = input(buff1);
    int len2 = input(buff2);

    sum(buff1, len1, buff2, len2, result, &result_length);
    for (int i = 0; i < result_length; i++) {
        printf("%d", result[i]);
        if (i < result_length - 1) {
            printf(" ");
        }
    }
    printf("\n");
    sub(buff1, len1, buff2, len2, result, &result_length);
    if (result_length == 0) {
        printf("n/a");
    } else {
        for (int i = 0; i < result_length; i++) {
            printf("%d", result[i]);
            if (i < result_length - 1) {
                printf(" ");
            }
        }
    }

    return 0;
}
