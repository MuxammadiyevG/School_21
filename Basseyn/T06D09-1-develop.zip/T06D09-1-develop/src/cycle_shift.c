#include <stdio.h>
#define NMAX 10

int input(int *a, int *n, int *c);
void output(int *a, int n);
void rotate(int *a, int n, int c);
void chap_sur(int *a, int n, int c);
void ong_sur(int *a, int n, int c);

int main() {
    int n, c, arr[NMAX];
    if (input(arr, &n, &c) != -1) {
        rotate(arr, n, c);
        output(arr, n);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *a, int *n, int *c) {
    char end;
    if (scanf("%d%c", n, &end) == 2 && end == '\n' && *n >= 1 && *n <= NMAX) {
        for (int i = 0; i < *n; i++) {
            if (scanf("%d", &a[i]) != 1) {
                return -1;
            }
        }
        if (scanf("%d%c", c, &end) == 2 && end == '\n') {
            return 0;
        }
    }
    return -1;
}

void output(int *a, int n) {
    for (int i = 0; i < n; i++) {
        if (i != 0) printf(" ");
        printf("%d", a[i]);
    }
    printf("\n");
}

void rotate(int *a, int n, int c) {
    if (c > 0) {
        chap_sur(a, n, c);
    } else if (c < 0) {
        ong_sur(a, n, -c);
    }
}

void chap_sur(int *a, int n, int c) {
    c %= n;
    int temp[NMAX];
    for (int i = 0; i < n; i++) {
        temp[i] = a[(i + c) % n];
    }
    for (int i = 0; i < n; i++) {
        a[i] = temp[i];
    }
}

void ong_sur(int *a, int n, int c) {
    c %= n;
    int temp[NMAX];
    for (int i = 0; i < n; i++) {
        temp[i] = a[(i + n - c) % n];
    }
    for (int i = 0; i < n; i++) {
        a[i] = temp[i];
    }
}
