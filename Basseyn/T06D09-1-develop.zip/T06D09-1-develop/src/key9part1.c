#include <stdio.h>
#define NMAX 10
int input(int *buffer, int *length);
void output(int *buffer, int length);
int sum_numbers(int *buffer, int length);
void find_numbers(int *buffer, int length, int sum_res);
int main() {
    int arr[NMAX], n;
    int *ptr;
    ptr = arr;
    if (input(ptr, &n) != -1) {
        if (sum_numbers(ptr, n) != -1) {
            find_numbers(ptr, n, sum_numbers(ptr, n));
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    return 0;
}

int sum_numbers(int *buffer, int length) {
    int sum = 0;

    for (int i = 0; i < length; i++) {
        if (buffer[i] % 2 == 0) {
            sum += buffer[i];
        }
    }
    if (sum == 0) {
        return -1;
    } else {
        return sum;
    }

    return sum;
}
int input(int *buffer, int *length) {
    char c;
    if (scanf("%d", length) == 1 && scanf("%c", &c) == 1 && c == '\n' && *length <= NMAX && *length >= 1) {
        for (int i = 0; i < *length; i++) {
            if (scanf("%d", buffer + i) != 1) {
                return -1;
            }
        }
        return 1;
    } else {
        return -1;
    }
}
void find_numbers(int *buffer, int length, int sum_res) {
    printf("%d\n", sum_res);
    for (int *i = buffer; i - buffer < length; i++) {
        if (*i != 0) {
            if (sum_res % *i == 0) {
                printf("%d ", *i);
            }
        }
    }
}
