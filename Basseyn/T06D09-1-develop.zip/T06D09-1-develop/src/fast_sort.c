#include <stdio.h>
#define NMAX 10

void swap(int *a, int *b);
int partition(int *arr, int low, int high);
void quickSort(int *arr, int low, int high);
void heapSort(int *arr, int N);
void heapify(int *arr, int N, int i);
int input(int *arr);
void output(int *arr, int n);

int main() {
    int arr[NMAX];
    int *ptr = arr;
    if (input(ptr) != -1) {
        quickSort(arr, 0, NMAX - 1);
        output(ptr, NMAX);
        heapSort(ptr, NMAX);
        output(ptr, NMAX);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *arr) {
    for (int i = 0; i < NMAX; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            return -1;
        }
    }
    return 0;
}

void output(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        if (i != 0) {
            printf(" ");
        }
        printf("%d", arr[i]);
    }
    printf("\n");
}

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int partition(int *arr, int low, int high) {
    int pivot = arr[low];
    int i = low + 1;
    int j = high;
    while (1) {
        while (i <= high && arr[i] <= pivot) {
            i++;
        }
        while (j >= low && arr[j] > pivot) {
            j--;
        }
        if (i >= j) {
            break;
        }
        swap(&arr[i], &arr[j]);
    }
    swap(&arr[low], &arr[j]);
    return j;
}

void quickSort(int *arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void heapify(int *arr, int N, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < N && arr[left] > arr[largest]) {
        largest = left;
    }
    if (right < N && arr[right] > arr[largest]) {
        largest = right;
    }
    if (largest != i) {
        swap(&arr[i], &arr[largest]);
        heapify(arr, N, largest);
    }
}

void heapSort(int *arr, int N) {
    for (int i = N / 2 - 1; i >= 0; i--) {
        heapify(arr, N, i);
    }
    for (int i = N - 1; i > 0; i--) {
        swap(&arr[0], &arr[i]);
        heapify(arr, i, 0);
    }
}
