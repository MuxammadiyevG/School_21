double max(double *data, int n) {
    double max = data[0];
    for (int i = 0; i < n; i++)
        if (data[i] > max) max = data[i];
    return max;
}

double min(double *data, int n) {
    double min = data[0];
    for (int i = 0; i < n; i++)
        if (data[i] < min) min = data[i];
    return min;
}

double mean(double *data, int n) {
    double mean = 0;
    for (int i = 0; i < n; i++) mean += data[i];
    return mean * 1.0 / n;
}
double variance(double *data, int n) {
    double mean_ = mean(data, n), Sum = 0;
    for (int i = 0; i < n; i++) {
        Sum += (data[i] - mean_) * ((data[i] - mean_));
    }
    return Sum * 1.0 / n;
}
