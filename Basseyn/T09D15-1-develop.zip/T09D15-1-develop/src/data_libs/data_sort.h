#ifndef DATA_SORT_H
#define DATA_SORT_H

void sort(double* data, int n);

#endif
