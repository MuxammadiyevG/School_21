#include <stdio.h>
int get_n() {
    int n;
    if (scanf("%d", &n) != 1) return -1;
    return n;
}

int input(double* data, int n) {
    for (int i = 0; i < n; i++)
        if (scanf("%lf", &(data[i])) != 1) {
            return -1;
            break;
        }
    return 0;
}

void output(double* data, int n) {
    for (int i = 0; i < n; i++) {
        printf("%.2lf", data[i]);
        if (i != n - 1) printf(" ");
    }
}
