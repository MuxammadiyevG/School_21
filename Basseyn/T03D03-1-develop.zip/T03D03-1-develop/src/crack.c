#include <stdio.h>
int main(){
	double a,b;
	if(scanf("%lf %lf",&a,&b)==2){;
	if(a*a+b*b<25){
	printf("GOTCHA\n");
}
else{
printf("MISS\n");
}}
else{
	printf("n/a\n");
}
return 0;
}
