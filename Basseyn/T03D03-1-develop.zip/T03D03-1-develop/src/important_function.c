#include <stdio.h>
#include <math.h> 

double y_(double x) {
    double y;
    y = 7e-3 * pow(x, 4) + ((22.8 * pow(x, 1.0/3) - 1e3) * x + 3) / (x * x / 2) - x * pow((10 + x), 2.0/x) - 1.01;
    
    return y;
}

int main() {
    double x, result;
    if (scanf("%lf", &x) == 1) {
        result = y_(x);
        printf("%.1lf\n", result);
    } else {
       
        printf("n/a\n");
    }
    
    return 0;
}

