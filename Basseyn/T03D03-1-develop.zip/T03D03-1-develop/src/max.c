#include <stdio.h>
int max(int a, int b) {
    return (a > b) ? a : b;
}

int main() {
    int num1, num2;
    char c;

    if ((scanf("%d %d", &num1, &num2) == 2)&&(scanf("%c",&c)==1)&&(c=='\n')) {
        int result = max(num1, num2);
        printf("%d\n", result);
    } else {
        printf("n/a\n");
    }
    
    return 0;
}

