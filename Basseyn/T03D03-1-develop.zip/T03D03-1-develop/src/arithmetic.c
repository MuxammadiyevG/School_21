#include <stdio.h>

int sum(int a, int b);
int difference(int a,int b);
int product(int a,int b);
int quotient(int a,int b);
int main()
{
     int a,b;
    scanf("%d%d",&a,&b);
    if(quotient(a,b)==-1){
	printf("%d %d %d %s\n",sum(a,b),difference(a,b),product(a,b),"n/a");
	}
    else{
	printf("%d %d %d %d\n",sum(a,b),difference(a,b),product(a,b),quotient(a,b));
    	}
    return 0;
}

int sum(int a, int b){
    return a+b;
}
int difference(int a,int b){
   if(a>b){
	return a-b;
	}
   else if(a==b){
	return 0;	
}
   else{
	return b-a;
	}
}
int product(int a,int b){
   return a*b;
}
int quotient(int a,int b){
   if(b!=0){
	return a/b;
	}
  else{
	return -1;
	}
}
