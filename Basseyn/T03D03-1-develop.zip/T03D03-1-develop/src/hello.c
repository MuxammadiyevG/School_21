#include <stdio.h>
int main()
{
printf("Hello, AI!\n");
return 0;

}
