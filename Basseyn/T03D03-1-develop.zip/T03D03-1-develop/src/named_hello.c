#include <stdio.h>
int main(){
	char name[100];
	printf("Ismingizni kiriting :");
	scanf("%s",name);
	printf("Hello ,%s!\n",name);
return 0;
}
