ps a | grep ai_door_control
kill -9 1274256
