mkdir door_management_files
cd door_management_files
mkdir door_configuration
mkdir door_map
mkdir door_logs
cd ..
mv /door_management_fi*.conf /door_management_files/door_configuration
mv /door_management_fi/door_map_1.1 /door_management_files/door_maps
mv /door_management_fi/*.log /door_management_files/door_logs
./ai_door_managment_module.sh
