cd ai_help
chmod +x *
./keygen.sh
cd key
rm -r file*
cd ..
./unifier.sh
cat main.key
"654"
ls

key
keygen.sh
main.key
unifier.sh
