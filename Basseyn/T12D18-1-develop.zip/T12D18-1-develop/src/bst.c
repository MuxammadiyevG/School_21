#include "bst.h"

#include <stdio.h>
#include <stdlib.h>

t_btree *bstree_create_node(int item) {
    t_btree *tmp = (t_btree *)malloc(sizeof(t_btree));
    if (tmp == NULL) {
        perror("Failed to allocate memory for new node");
        exit(EXIT_FAILURE);
    }
    tmp->val = item;
    tmp->left = NULL;
    tmp->right = NULL;
    return tmp;
}

int compare(int x, int y) {
    if (x >= y) return 1;
    return -1;
}

void bstree_insert(t_btree *root, int item, int (*cmpf)(int, int)) {
    int cmp = cmpf(root->val, item);
    if (cmp >= 0) {  // Change to handle equal values correctly
        if (root->left == NULL) {
            root->left = bstree_create_node(item);
        } else {
            bstree_insert(root->left, item, cmpf);
        }
    } else {
        if (root->right == NULL) {
            root->right = bstree_create_node(item);
        } else {
            bstree_insert(root->right, item, cmpf);
        }
    }
}

void bstree_apply_infix(t_btree *root, void (*applyf)(int)) {
    if (root == NULL) return;
    if (root->left != NULL) bstree_apply_infix(root->left, applyf);
    applyf(root->val);
    if (root->right != NULL) bstree_apply_infix(root->right, applyf);
}

void bstree_apply_prefix(t_btree *root, void (*applyf)(int)) {
    if (root == NULL) return;
    applyf(root->val);
    if (root->left != NULL) bstree_apply_prefix(root->left, applyf);
    if (root->right != NULL) bstree_apply_prefix(root->right, applyf);
}

void bstree_apply_postfix(t_btree *root, void (*applyf)(int)) {
    if (root == NULL) return;
    if (root->left != NULL) bstree_apply_postfix(root->left, applyf);
    if (root->right != NULL) bstree_apply_postfix(root->right, applyf);
    applyf(root->val);
}

void printNode(int val) { printf("%d ", val); }
