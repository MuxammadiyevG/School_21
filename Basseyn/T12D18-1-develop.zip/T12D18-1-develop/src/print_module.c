#include "print_module.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Ensure Log_prefix is defined in print_module.h
// For example: extern const char* Log_prefix;

char print_char(char ch) { return putchar(ch); }

void print_log(char (*print)(char), char* message) {
    time_t raw;
    struct tm timeinfo;
    time(&raw);
    localtime_r(&raw, &timeinfo);

    int hour = timeinfo.tm_hour;
    int min = timeinfo.tm_min;
    int sec = timeinfo.tm_sec;
    printf("%s %02d:%02d:%02d ", Log_prefix, hour, min, sec);

    while (*message != '\0') {
        print(*message);
        message++;
    }
    printf("\n");  // Add a newline for better formatting
}

void print_docs(short mask, int documents_count, ...) {
    va_list ptr;
    va_start(ptr, documents_count);
    int ct = 0;
    while (documents_count--) {
        char* str = va_arg(ptr, char*);
        ct++;
        if ((mask & 1) == 1) {
            printf("%d.%-15s: available\n", ct, str);
        } else {
            printf("%d.%-15s: unavailable\n", ct, str);
        }
        mask >>= 1;
    }
    va_end(ptr);
}
