#include <stdio.h>
#include <stdlib.h>

#include "bst.h"

void bst_traverse_test();

int main() {
    bst_traverse_test();
    return 0;  // Ensure main returns an int
}

void bst_traverse_test() {
    t_btree* tmp1 = bstree_create_node(45);
    if (tmp1 == NULL) {
        printf("Memory allocation for tmp1 failed\n");
        return;
    }

    bstree_insert(tmp1, 12, compare);
    bstree_insert(tmp1, 6, compare);
    bstree_insert(tmp1, 50, compare);

    printf("func must print: <6 12 45 50>\n");
    bstree_apply_infix(tmp1, printNode);
    printf("\n");

    printf("func must print: <45 12 6 50>\n");
    bstree_apply_prefix(tmp1, printNode);
    printf("\n");

    printf("func must print: <6 12 50 45>\n");
    bstree_apply_postfix(tmp1, printNode);
    printf("\n");

    // Free allocated memory
    free(tmp1->left->left);
    free(tmp1->left);
    free(tmp1->right);
    free(tmp1);
}
