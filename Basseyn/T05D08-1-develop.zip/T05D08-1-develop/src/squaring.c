#include <stdio.h>
#define NMAX 10

int input(int *a, int *n);
void output(int *a, int n);
void squaring(int *a, int n);

int main() {
    int n, data[NMAX];
    int *p;
    p = data;
    if (input(p, &n) != -1) {
        ;
        squaring(p, n);
        output(p, n);
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *a, int *n) {
    char l;
    int count = 0;
    if (scanf("%d", n) == 1 && scanf("%c", &l) == 1 && l == '\n' && *n > 0 && *n <= NMAX) {
        for (int *p = a; p - a < *n; p++) {
            if (scanf("%d", p) == 1) count++;
            if (count > *n) {
                return -1;
            }
        }
        return 1;
    } else {
        return -1;
    }
}

void output(int *a, int n) {
    int k = 0;
    while (k < n) {
        printf("%d ", *(a + k));
        k++;
    }
}

void squaring(int *a, int n) {
    int l = 0;
    while (l < n) {
        *(a + l) = *(a + l) * (*(a + l));
        l++;
    }
}
