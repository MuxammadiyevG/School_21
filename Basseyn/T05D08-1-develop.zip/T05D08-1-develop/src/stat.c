#include <stdio.h>
#define NMAX 10

int input(int *a, int *n);
void output(int *a, int n);
int max(int *a, int n);
int min(int *a, int n);
double mean(int *a, int n);
double variance(int *a, int n);

void output_result(int max_v, int min_v, double mean_v, double variance_v);

int main() {
    int n, data[NMAX];
    int *p;
    p = data;
    if (input(p, &n) != -1) {
        output(p, n);
        output_result(max(p, n), min(p, n), mean(p, n), variance(p, n));
    } else {
        printf("n/a");
    }
    return 0;
}
int input(int *a, int *n) {
    char c;
    int result = 0;
    if (scanf("%d", n) == 1 && scanf("%c", &c) == 1 && c == '\n') {
        if (*n > 0 && *n < 10) {
            for (int *i = a; i - a < *n; i++) {
                scanf("%d", i);
            }
        } else {
            result = -1;
        }
    } else {
        result = -1;
    }
    return result;
}
void output(int *a, int n) {
    int count = 0;
    while (count < n) {
        printf("%d ", *(a + count));
        count++;
    }
    printf("\n");
}
int max(int *a, int n) {
    int max = *a;
    int count = 0;
    while (count < n) {
        if (max < *(a + count)) {
            max = *(a + count);
        }
        count++;
    }
    return max;
}
int min(int *a, int n) {
    int min = *a;
    int count = 0;
    while (count < n) {
        if (min > *(a + count)) {
            min = *(a + count);
        }
        count++;
    }
    return min;
}
double mean(int *a, int n) {
    double Sum = 0;
    int count = 0;
    while (count < n) {
        Sum += *(count + a);
        count++;
    }
    return Sum / n;
}
double variance(int *a, int n) {
    double ortacha = mean(a, n);
    int count = 0;
    double Sum_dis = 0;
    while (count < n) {
        Sum_dis += (ortacha - *(count + a)) * (ortacha - *(count + a));
        count++;
    }
    return Sum_dis / n;
}
void output_result(int max_v, int min_v, double mean_v, double variance_v) {
    printf("%d %d %.6lf %.6lf", max_v, min_v, mean_v, variance_v);
}
