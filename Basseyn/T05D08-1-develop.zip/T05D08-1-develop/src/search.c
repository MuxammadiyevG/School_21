#include <math.h>
#include <stdio.h>
#define NMAX 30
double variance(int *a, int n);
int input(int *a, int *n);
void output(int *a, int n);
double mean(int *a, int n);
void output_result(int *a, int n, double mean, double variance);
int main() {
    int n, data[NMAX];
    int *p;
    p = data;
    if (input(p, &n) != -1) {
        output_result(p, n, mean(p, n), variance(p, n));
    } else {
        printf("n/a");
    }
    return 0;
}

int input(int *a, int *n) {
    char c;
    int result = 0;
    if (scanf("%d", n) == 1 && scanf("%c", &c) == 1 && c == '\n' && *n > 0 && *n <= 30) {
        for (int *i = a; i - a < *n; i++) {
            scanf("%d", i);
        }
        result = 0;
    } else {
        result = -1;
    }
    return result;
}

double variance(int *a, int n) {
    double ortacha = mean(a, n);
    int count = 0;
    double Sum_dis = 0;
    while (count < n) {
        Sum_dis += (ortacha - *(count + a)) * (ortacha - *(count + a));
        count++;
    }
    return Sum_dis / n;
}

double mean(int *a, int n) {
    double Sum = 0;
    int count = 0;
    while (count < n) {
        Sum += *(count + a);
        count++;
    }
    return Sum / n;
}
void output_result(int *a, int n, double mean, double variance) {
    int count = 0;
    int l = 0;
    while (count < n) {
        if ((*(a + count) % 2 == 0) && (*(a + count) >= mean) &&
            (*(a + count) <= mean + 3 * sqrt(variance)) && (*(a + count) != 0)) {
            printf("%d ", *(a + count));
            l++;
        }
        count++;
    }
    if (l == 0) {
        printf("%d", 0);
    }
}
