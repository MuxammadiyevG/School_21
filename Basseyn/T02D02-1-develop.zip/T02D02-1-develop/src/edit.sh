#!/bin/bash

if [ "$#" -ne 3 ]; then
    echo "Qo'llanishi: $0 <Faylga bo'lgan yo'lni ko'rsating > <o'zgartirmoqchi bo'lgan so'zingizni kiriting > <So'z qaysiz so'zga o'zgarishi kerak>"
    echo "Masalan : /home/danetttw/a/index.txt  uchun kerak"
    exit 1
fi

file_path="$1"
string_to_replace="$2"
replacement_string="$3"

if [ ! -f "$file_path" ]; then
    echo "Error: fayl nomi topilmadi !! '$file_path'."
    exit 1
fi

timestamp=$(date +"%Y-%m-%d %H:%M:%S")
backup_file="${file_path}.${timestamp//[-: ]}.bak"
cp "$file_path" "$backup_file"
sed -i "s/$string_to_replace/$replacement_string/g" "$file_path"

# Fayl hajmini olish
file_size=$(stat -c%s "$file_path")

# SHA256 hashni hisoblash
file_hash=$(sha256sum "$file_path" | awk '{ print $1 }')

log_entry="${file_path} - ${file_size} - ${timestamp} - ${file_hash} - sha256"
echo "$log_entry" >> src/files.log

echo "O'zgarishlar saqlandi src/files.log."

