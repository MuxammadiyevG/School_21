#!/bin/bash

if [ -z "$1" ]; then
  echo "Error: No file path provided."
  exit 1
fi


file_path="$1"


if [ ! -f "$file_path" ] || [ ! -r "$file_path" ]; then
  echo "Fayl yo'q"
  exit 1
fi


total_records=0
declare -A unique_files
changes_in_hash=0

while IFS= read -r line; do
  total_records=$((total_records + 1))
  
  
  log_file=$(echo "$line" | awk '{print $2}')
  log_hash=$(echo "$line" | awk '{print $3}')
  unique_files["$log_file"]=1
  if [ "$log_hash" != "-" ]; then
    changes_in_hash=$((changes_in_hash + 1))
  fi
done < "$file_path"

echo "$total_records ${#unique_files[@]} $changes_in_hash"
