#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>

#define WIDTH 80
#define HEIGHT 25
#define PADDLE_HEIGHT 3
#define BALL_SPEED 1

typedef struct {
    int x, y;
} Paddle;

typedef struct {
    int x, y, dx, dy;
} Ball;

Paddle left_paddle = {1, HEIGHT / 2 - PADDLE_HEIGHT / 2};
Paddle right_paddle = {WIDTH - 2, HEIGHT / 2 - PADDLE_HEIGHT / 2};
Ball ball = {WIDTH / 2, HEIGHT / 2, BALL_SPEED, BALL_SPEED};

int left_score = 0;
int right_score = 0;

int kbhit(void) {
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if (ch != EOF) {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}

void handle_input() {
    if (kbhit()) {
        char c = getchar();
        if ((c == 'a' || c == 'A') && left_paddle.y > 0) left_paddle.y--;
        if ((c == 'z' || c == 'Z') && left_paddle.y < HEIGHT - PADDLE_HEIGHT) left_paddle.y++;
        if ((c == 'k' || c == 'K') && right_paddle.y > 0) right_paddle.y--;
        if ((c == 'm' || c == 'M') && right_paddle.y < HEIGHT - PADDLE_HEIGHT) right_paddle.y++;
    }
}
/*
void update_ball() {
    ball.x += ball.dx;
    ball.y += ball.dy;

    if (ball.y <= 0 || ball.y >= HEIGHT - 1) {
        ball.dy = -ball.dy;
    }

    if ((ball.x == left_paddle.x + 1 && ball.y >= left_paddle.y && ball.y <= left_paddle.y + PADDLE_HEIGHT -
1) || (ball.x == right_paddle.x - 1 && ball.y >= right_paddle.y && ball.y <= right_paddle.y + PADDLE_HEIGHT -
1)) { ball.dx = -ball.dx;
    }

    if (ball.x < 0) {
        right_score++;
        if (right_score >= 21) {
            printf("\nCongratulations! Right Player wins!\n");
            exit(0); // Game ends
        }
        ball.x = WIDTH / 2;
        ball.y = HEIGHT / 2;
        ball.dx = BALL_SPEED;
        ball.dy = BALL_SPEED;
    }

    if (ball.x > WIDTH) {
        left_score++;
        if (left_score >= 21) {
            printf("\nCongratulations! Left Player wins!\n");
            exit(0); // Game ends
        }
        ball.x = WIDTH / 2;
        ball.y = HEIGHT / 2;
        ball.dx = BALL_SPEED;
        ball.dy = BALL_SPEED;
    }
}
*/
void update_ball() {
    ball.x += ball.dx;
    ball.y += ball.dy;

    if (ball.y <= 0 || ball.y >= HEIGHT - 1) {
        ball.dy = -ball.dy;
    }

    if ((ball.x == left_paddle.x + 1 && ball.y >= left_paddle.y &&
         ball.y <= left_paddle.y + PADDLE_HEIGHT - 1) ||
        (ball.x == right_paddle.x - 1 && ball.y >= right_paddle.y &&
         ball.y <= right_paddle.y + PADDLE_HEIGHT - 1)) {
        ball.dx = -ball.dx;
    }

    if (ball.x < 0) {
        right_score++;
        if (right_score >= 21) {
            printf("\nTabriklaymiz! O'ng o'yinchisi g'alaba qozonadi!\n");
            exit(0);
        }
        ball.x = WIDTH / 2;
        ball.y = HEIGHT / 2;
        ball.dx = BALL_SPEED;
    }

    if (ball.x > WIDTH) {
        left_score++;
        if (left_score >= 21) {
            printf("\nTabriklaymiz! Chap o'yinchisi g'alaba qozonadi!\n");
            exit(0);
        }
        ball.x = WIDTH / 2;
        ball.y = HEIGHT / 2;
        ball.dx = -BALL_SPEED;
    }
}

void render() {
    system("clear");

    for (int x = 0; x < WIDTH + 2; x++) {
        printf("-");
    }
    printf("\n");

    for (int y = 0; y < HEIGHT; y++) {
        printf("|");
        for (int x = 0; x < WIDTH; x++) {
            if (x == left_paddle.x && y >= left_paddle.y && y < left_paddle.y + PADDLE_HEIGHT) {
                printf("|");
            } else if (x == right_paddle.x && y >= right_paddle.y && y < right_paddle.y + PADDLE_HEIGHT) {
                printf("|");
            } else if (x == ball.x && y == ball.y) {
                printf("o");
            } else if (x == WIDTH / 2) {
                printf("|");
            } else {
                printf(" ");
            }
        }
        printf("|\n");
    }

    for (int x = 0; x < WIDTH + 2; x++) {
        printf("-");
    }
    printf("\n");

    printf("Left Player: %d  |  Right Player: %d\n", left_score, right_score);
}

int main() {
    while (1) {
        handle_input();
        update_ball();
        render();
        usleep(100000);
    }
    return 0;
}
