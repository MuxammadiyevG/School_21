#include <stdio.h>
#include <stdlib.h>

void sort(int *a, int n);
int input(int *a, int n);
int input_n(int *n);
void output(int *a, int n);

int main() {
    int n;
    if (input_n(&n) != -1) {
        int *arr = (int *)malloc(n * sizeof(int));
        if (arr == NULL) {
            printf("n/a");
            return 1;
        }

        if (input(arr, n) != -1) {
            sort(arr, n);
            output(arr, n);
        } else {
            printf("n/a");
        }

        free(arr);
    } else {
        printf("n/a");
    }

    return 0;
}

int input_n(int *n) {
    char c;
    if (scanf("%d%c", n, &c) == 2 && *n >= 1 && c == '\n') {
        return *n;
    } else {
        return -1;
    }
}

int input(int *a, int n) {
    int count = 0;
    while (count < n) {
        if (scanf("%d", a + count) != 1) {
            return -1;
        }
        count++;
    }
    return 0;
}

void output(int *a, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d", *(a + i));
        if (i < n - 1) {
            printf(" ");
        }
    }
}

void sort(int *a, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (*(a + i) > *(a + j)) {
                int temp = *(a + i);
                *(a + i) = *(a + j);
                *(a + j) = temp;
            }
        }
    }
}
