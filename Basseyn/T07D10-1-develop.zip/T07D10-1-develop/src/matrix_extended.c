#include <stdio.h>
#include <stdlib.h>
#define NMAX 100

int input_select_method(int *method);
int input_size(int *columns, int *rows);
int static_input_and_output_array_elements(int input_size_columns, int input_size_rows);
void first_dynamic(int input_size_columns, int input_size_rows);
void second_dynamic(int input_size_columns, int input_size_rows);
void third_dynamic(int input_size_columns, int input_size_rows);
void input_d(int **matrix, int s, int c);
void find_max_in_rows(int **matrix, int rows, int cols, int *max_in_rows);
void find_min_in_cols(int **matrix, int rows, int cols, int *min_in_cols);

int main() {
    int input_select, input_size_columns, input_size_rows;
    input_select_method(&input_select);
    if (input_select <= 4 && input_select > 0) {
        input_size(&input_size_columns, &input_size_rows);
        if (input_size_columns <= 100 && input_size_rows <= 100 && input_size_columns > 0 &&
            input_size_rows > 0) {
            if (input_select == 1) {
                static_input_and_output_array_elements(input_size_columns, input_size_rows);
            } else if (input_select == 2) {
                first_dynamic(input_size_columns, input_size_rows);
            } else if (input_select == 3) {
                second_dynamic(input_size_columns, input_size_rows);
            } else if (input_select == 4) {
                third_dynamic(input_size_columns, input_size_rows);
            } else {
                printf("n/a");
            }
        } else {
            printf("n/a");
        }
    } else {
        printf("n/a");
    }
    return 0;
}

int input_select_method(int *method) {
    scanf("%d", method);
    return *method;
}

int input_size(int *input_size_columns, int *input_size_rows) {
    scanf("%d %d", input_size_columns, input_size_rows);
    return 0;
}

int static_input_and_output_array_elements(int input_size_columns, int input_size_rows) {
    int array[input_size_rows][input_size_columns];
    for (int row = 0; row < input_size_rows; row++) {
        for (int column = 0; column < input_size_columns; column++) {
            scanf("%d", &array[row][column]);
        }
    }

    for (int row = 0; row < input_size_rows; row++) {
        for (int column = 0; column < input_size_columns; column++) {
            printf("%d ", array[row][column]);
        }
        printf("\n");
    }

    int max_in_rows[input_size_rows];
    int min_in_cols[input_size_columns];
    for (int i = 0; i < input_size_rows; i++) {
        int max = array[i][0];
        for (int j = 1; j < input_size_columns; j++) {
            if (array[i][j] > max) {
                max = array[i][j];
            }
        }
        max_in_rows[i] = max;
    }

    for (int j = 0; j < input_size_columns; j++) {
        int min = array[0][j];
        for (int i = 1; i < input_size_rows; i++) {
            if (array[i][j] < min) {
                min = array[i][j];
            }
        }
        min_in_cols[j] = min;
    }

    for (int i = 0; i < input_size_rows; i++) {
        printf("%d ", max_in_rows[i]);
    }
    printf("\n");

    for (int j = 0; j < input_size_columns; j++) {
        printf("%d ", min_in_cols[j]);
    }
    printf("\n");

    return 0;
}

void input_d(int **matrix, int input_size_columns, int input_size_rows) {
    for (int i = 0; i < input_size_rows; i++) {
        for (int k = 0; k < input_size_columns; k++) {
            scanf("%d", &matrix[i][k]);
        }
    }
}

void output(int **a, int input_size_columns, int input_size_rows) {
    for (int k = 0; k < input_size_rows; k++) {
        for (int i = 0; i < input_size_columns; i++) {
            printf("%d ", a[k][i]);
        }
        printf("\n");
    }
}

void find_max_in_rows(int **matrix, int rows, int cols, int *max_in_rows) {
    for (int i = 0; i < rows; i++) {
        int max = matrix[i][0];
        for (int j = 1; j < cols; j++) {
            if (matrix[i][j] > max) {
                max = matrix[i][j];
            }
        }
        max_in_rows[i] = max;
    }
}

void find_min_in_cols(int **matrix, int rows, int cols, int *min_in_cols) {
    for (int j = 0; j < cols; j++) {
        int min = matrix[0][j];
        for (int i = 1; i < rows; i++) {
            if (matrix[i][j] < min) {
                min = matrix[i][j];
            }
        }
        min_in_cols[j] = min;
    }
}

void first_dynamic(int input_size_columns, int input_size_rows) {
    int **matrix =
        malloc(input_size_rows * sizeof(int *) + input_size_rows * input_size_columns * sizeof(int));
    int *save = (int *)(matrix + input_size_rows);
    for (int i = 0; i < input_size_rows; i++) {
        matrix[i] = save + input_size_columns * i;
    }
    input_d(matrix, input_size_columns, input_size_rows);
    output(matrix, input_size_columns, input_size_rows);

    int max_in_rows[input_size_rows];
    int min_in_cols[input_size_columns];
    find_max_in_rows(matrix, input_size_rows, input_size_columns, max_in_rows);
    find_min_in_cols(matrix, input_size_rows, input_size_columns, min_in_cols);

    for (int i = 0; i < input_size_rows; i++) {
        printf("%d ", max_in_rows[i]);
    }
    printf("\n");

    for (int j = 0; j < input_size_columns; j++) {
        printf("%d ", min_in_cols[j]);
    }
    printf("\n");

    free(matrix);
}

void second_dynamic(int input_size_columns, int input_size_rows) {
    int **matrix = malloc(input_size_rows * sizeof(int *));
    for (int i = 0; i < input_size_rows; i++) {
        matrix[i] = malloc(input_size_columns * sizeof(int));
    }
    input_d(matrix, input_size_columns, input_size_rows);
    output(matrix, input_size_columns, input_size_rows);

    int max_in_rows[input_size_rows];
    int min_in_cols[input_size_columns];
    find_max_in_rows(matrix, input_size_rows, input_size_columns, max_in_rows);
    find_min_in_cols(matrix, input_size_rows, input_size_columns, min_in_cols);

    for (int i = 0; i < input_size_rows; i++) {
        printf("%d ", max_in_rows[i]);
    }
    printf("\n");

    for (int j = 0; j < input_size_columns; j++) {
        printf("%d ", min_in_cols[j]);
    }
    printf("\n");

    for (int i = 0; i < input_size_rows; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

void third_dynamic(int input_size_columns, int input_size_rows) {
    int **matrix =
        malloc(input_size_rows * sizeof(int *) + input_size_rows * input_size_columns * sizeof(int));
    int *save = (int *)(matrix + input_size_rows);
    for (int i = 0; i < input_size_rows; i++) {
        matrix[i] = save + input_size_columns * i;
    }
    input_d(matrix, input_size_columns, input_size_rows);
    output(matrix, input_size_columns, input_size_rows);

    int max_in_rows[input_size_rows];
    int min_in_cols[input_size_columns];
    find_max_in_rows(matrix, input_size_rows, input_size_columns, max_in_rows);
    find_min_in_cols(matrix, input_size_rows, input_size_columns, min_in_cols);

    for (int i = 0; i < input_size_rows; i++) {
        printf("%d ", max_in_rows[i]);
    }
    printf("\n");

    for (int j = 0; j < input_size_columns; j++) {
        printf("%d ", min_in_cols[j]);
    }
    printf("\n");

    free(matrix);
}
