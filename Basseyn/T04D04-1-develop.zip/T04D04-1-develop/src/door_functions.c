#include <math.h>
#include <stdio.h>

#define PI 3.141592653589793
#define MEASUREMENTS 42

double witch_of_agnesi(double x) { return pow(1, 3) / (pow(1, 2) + pow(x, 2)); }

double lemniscate_of_bernoulli(double x) {
  double val =
      sqrt(sqrt(pow(1, 4) + 4 * pow(x, 2) * pow(1, 2)) - pow(x, 2) - pow(1, 2));
  return isnan(val) ? -1 : val;
}

double quadratic_hyperbola(double x) {
  if (x == 0)
    return -1; // Undefined at x = 0
  return 1 / pow(x, 2);
}

int main() {
  double step = 2 * PI / (MEASUREMENTS - 1);
  for (int i = 0; i < MEASUREMENTS; i++) {
    double x = -PI + i * step;
    double y_wa = witch_of_agnesi(x);
    double y_lb = lemniscate_of_bernoulli(x);
    double y_qh = quadratic_hyperbola(x);

    printf("%.7f|", x);
    printf("%.7f|", y_wa);
    if (y_lb < 0)
      printf("-|");
    else
      printf("%.7f|", y_lb);
    if (y_qh < 0)
      printf("-\n");
    else
      printf("%.7f\n", y_qh);
  }

  return 0;
}
