#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int divide(int first, int second);
int is_prime(int num);
int largest_prime_divisor(int a);
int is_valid_integer(const char *str);

int main() {
  char input[100];
  int number, result;

  if (fgets(input, sizeof(input), stdin) == NULL || !is_valid_integer(input)) {
    printf("n/a\n");
    return 1;
  }

  number = atoi(input);
  number = abs(number);
  if (number <= 1) {
    printf("n/a\n");
    return 1;
  }

  result = largest_prime_divisor(number);
  if (result == -1) {
    printf("n/a\n");
  } else {
    printf("%d\n", result);
  }

  return 0;
}

int divide(int numerator, int denominator) {
  int quotient = 0;
  while (numerator >= denominator) {
    numerator -= denominator;
    quotient++;
  }
  return quotient;
}

int is_prime(int num) {
  if (num <= 1)
    return 0;
  if (num <= 3)
    return 1;

  for (int i = 2; i * i <= num; i++) {
    if (divide(num, i) * i == num)
      return 0;
  }
  return 1;
}

int largest_prime_divisor(int a) {
  int max_prime = -1;

  for (int i = 2; i <= a; i++) {
    while (a > 1 && is_prime(i) && divide(a, i) * i == a) {
      max_prime = i;
      a = divide(a, i);
    }
  }
  return max_prime;
}
int is_valid_integer(const char *str) {
  int i = 0;
  if (str[0] == '-') {
    i = 1;
  }
  for (; i < strlen(str) - 1; i++) {
    if (!isdigit(str[i])) {
      return 0;
    }
  }

  return 1;
}
