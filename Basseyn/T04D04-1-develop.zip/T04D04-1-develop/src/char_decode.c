#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void encode(char *input);
void decode(char *input);
int is_hex_string(char *str);

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("n/a\n");
    return 1;
  }

  int mode = atoi(argv[1]);
  if (mode != 0 && mode != 1) {
    printf("n/a\n");
    return 1;
  }

  char input[256];
  if (fgets(input, sizeof(input), stdin) == NULL) {
    printf("n/a\n");
    return 1;
  }

  // Remove the newline character from the input if present
  input[strcspn(input, "\n")] = 0;

  if (mode == 0) {
    encode(input);
  } else if (mode == 1) {
    decode(input);
  }

  return 0;
}

void encode(char *input) {
  int length = strlen(input);
  for (int i = 0; i < length; i++) {
    if (!isprint(input[i])) {
      printf("n/a\n");
      return;
    }
  }

  char *token = strtok(input, " ");
  while (token != NULL) {
    if (strlen(token) != 1) {
      printf("n/a\n");
      return;
    }
    printf("%02X", token[0]);
    token = strtok(NULL, " ");
    if (token != NULL) {
      printf(" ");
    }
  }
  printf("\n");
}

void decode(char *input) {
  char *token = strtok(input, " ");
  while (token != NULL) {
    if (!is_hex_string(token) || strlen(token) != 2) {
      printf("n/a\n");
      return;
    }
    int value;
    sscanf(token, "%x", &value);
    if (!isprint(value)) {
      printf("n/a\n");
      return;
    }
    printf("%c", value);
    token = strtok(NULL, " ");
    if (token != NULL) {
      printf(" ");
    }
  }
  printf("\n");
}

int is_hex_string(char *str) {
  for (int i = 0; i < strlen(str); i++) {
    if (!isxdigit(str[i])) {
      return 0;
    }
  }
  return 1;
}
