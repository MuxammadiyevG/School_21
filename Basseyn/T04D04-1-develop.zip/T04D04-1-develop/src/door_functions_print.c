#include <math.h>
#include <stdio.h>
#include <string.h>

#define PI 3.141592653589793
#define MEASUREMENTS 42
#define Y_SCALE 21
#define X_SCALE MEASUREMENTS
#define Y_MIN -1
#define Y_MAX 1

double witch_of_agnesi(double x) { return pow(1, 3) / (pow(1, 2) + pow(x, 2)); }

double lemniscate_of_bernoulli(double x) {
  double val =
      sqrt(sqrt(pow(1, 4) + 4 * pow(x, 2) * pow(1, 2)) - pow(x, 2) - pow(1, 2));
  return isnan(val) ? -1 : val;
}

double quadratic_hyperbola(double x) {
  if (x == 0)
    return -1;
  return 1 / pow(x, 2);
}

void plot_function(double (*func)(double), char plot[Y_SCALE][X_SCALE],
                   char symbol) {
  for (int i = 0; i < MEASUREMENTS; i++) {
    double x = -PI + i * (2 * PI / (MEASUREMENTS - 1));
    double y = func(x);

    if (y >= Y_MIN && y <= Y_MAX) {
      int y_pos = (int)((y - Y_MIN) / (Y_MAX - Y_MIN) * (Y_SCALE - 1));
      plot[Y_SCALE - 1 - y_pos][i] = symbol;
    }
  }
}

void initialize_plot(char plot[Y_SCALE][X_SCALE]) {
  for (int i = 0; i < Y_SCALE; i++) {
    for (int j = 0; j < X_SCALE; j++) {
      plot[i][j] = ' ';
    }
  }
}

void print_plot(char plot[Y_SCALE][X_SCALE]) {
  for (int i = 0; i < Y_SCALE; i++) {
    for (int j = 0; j < X_SCALE; j++) {
      printf("%c", plot[i][j]);
    }
    printf("\n");
  }
}

int main() {
  char plot[Y_SCALE][X_SCALE];
  initialize_plot(plot);

  plot_function(witch_of_agnesi, plot, '*');
  plot_function(lemniscate_of_bernoulli, plot, '*');
  plot_function(quadratic_hyperbola, plot, '*');

  print_plot(plot);

  return 0;
}
