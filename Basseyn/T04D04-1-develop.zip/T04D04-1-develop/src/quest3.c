#include <stdio.h>
#include <stdlib.h>

int fibonacci(int n);

int main() {
  int n;
  if (scanf("%d", &n) != 1) {
    printf("n/a\n");
    return 1;
  }

  if (n < 0) {
    printf("n/a\n");
    return 1;
  }

  int result = fibonacci(n);
  printf("%d\n", result);

  return 0;
}

int fibonacci(int n) {
  if (n == 0) {
    return 0;
  }
  if (n == 1) {
    return 1;
  }
  return fibonacci(n - 1) + fibonacci(n - 2);
}
