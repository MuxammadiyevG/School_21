#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define WIDTH 80
#define HEIGHT 25

int field[HEIGHT][WIDTH];
int width, height;

void init();
void term();
void step();
int neighbours(int x, int y);
void frame();

int main() {
    init();

    while (1) {
        frame();
        step();
        usleep(100000);
    }

    return 0;
}

void init() {
    struct sigaction act;
    act.sa_handler = term;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGINT, &act, NULL);

    width = getenv("COLUMNS") ? atoi(getenv("COLUMNS")) : WIDTH;
    height = getenv("LINES") ? atoi(getenv("LINES")) : HEIGHT;

    printf("\e[?25l\e[2J");

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            field[y][x] = rand() % 2;
        }
    }
}

void term() {
    printf("\e[?25h\e[1;1H\e[0m\e[2JThank you!\n");
    exit(0);
}

void step() {
    int newField[HEIGHT][WIDTH];

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int n = neighbours(x, y);
            if (field[y][x]) {
                newField[y][x] = (n >= 2 && n <= 3) ? 1 : 0;
            } else {
                newField[y][x] = (n == 3) ? 1 : 0;
            }
        }
    }

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            field[y][x] = newField[y][x];
        }
    }
}

int neighbours(int x, int y) {
    return field[y][(x + 1) % width] + field[(y + 1) % height][(x + 1) % width] + field[(y + 1) % height][x] +
           field[(y + 1) % height][(x - 1 + width) % width] + field[y][(x - 1 + width) % width] +
           field[(y - 1 + height) % height][(x - 1 + width) % width] + field[(y - 1 + height) % height][x] +
           field[(y - 1 + height) % height][(x + 1) % width];
}

void frame() {
    printf("\e[1;1H");

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            printf("\e[%d;%dH", y + 1, x + 1);
            if (field[y][x]) {
                printf("\e[1;33m0");
            } else {
                printf("\e[0;34mo");
            }
        }
    }
}
