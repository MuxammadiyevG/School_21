#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#define WIDTH 80
#define HEIGHT 25
#define SLEEP_TIME 100000

typedef struct {
    int **current;
    int **next;
    int speed;
} GameState;

void initializeGame(const char *filename, GameState *game);
void displayGame(GameState *game);
void updateGame(GameState *game);
int countNeighbors(GameState *game, int x, int y);
void handleInput(GameState *game);
void cleanup(GameState *game);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <initial_state_file>\n", argv[0]);
        return 1;
    }

    GameState game;
    game.speed = SLEEP_TIME;

    initializeGame(argv[1], &game);

    while (1) {
        displayGame(&game);
        updateGame(&game);
        handleInput(&game);
        usleep(game.speed);
    }

    cleanup(&game);
    return 0;
}

void initializeGame(const char *filename, GameState *game) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        exit(1);
    }

    game->current = malloc(HEIGHT * sizeof(int *));
    game->next = malloc(HEIGHT * sizeof(int *));
    for (int i = 0; i < HEIGHT; i++) {
        game->current[i] = malloc(WIDTH * sizeof(int));
        game->next[i] = malloc(WIDTH * sizeof(int));
    }

    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            game->current[i][j] = fgetc(file) == '1' ? 1 : 0;
        }
        fgetc(file);
    }

    fclose(file);
}

void displayGame(GameState *game) {
    printf("\033[H");
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            printf(game->current[i][j] ? "O" : " ");
        }
        printf("\n");
    }
}

void updateGame(GameState *game) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            int neighbors = countNeighbors(game, i, j);
            if (game->current[i][j] == 1) {
                game->next[i][j] = (neighbors == 2 || neighbors == 3) ? 1 : 0;
            } else {
                game->next[i][j] = (neighbors == 3) ? 1 : 0;
            }
        }
    }

    int **temp = game->current;
    game->current = game->next;
    game->next = temp;
}

int countNeighbors(GameState *game, int x, int y) {
    int count = 0;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue;
            int nx = (x + i + HEIGHT) % HEIGHT;
            int ny = (y + j + WIDTH) % WIDTH;
            count += game->current[nx][ny];
        }
    }
    return count;
}

void handleInput(GameState *game) {
    struct timeval tv = {0, 0};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);

    if (select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv) > 0) {
        char c = getchar();
        if (c == '+') {
            game->speed = game->speed > 10000 ? game->speed - 10000 : game->speed;
        } else if (c == '-') {
            game->speed += 10000;
        } else if (c == 'q') {
            cleanup(game);
            exit(0);
        }
    }
}

void cleanup(GameState *game) {
    for (int i = 0; i < HEIGHT; i++) {
        free(game->current[i]);
        free(game->next[i]);
    }
    free(game->current);
    free(game->next);
}
